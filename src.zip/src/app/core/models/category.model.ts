export interface Category {
  id?: number;
  name: string;
  description?: string;
  iconUrl?: string;
}